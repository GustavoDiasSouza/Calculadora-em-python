
  n1 = int(calculadora.nA.text())